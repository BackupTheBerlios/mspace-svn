using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("MSpace ComponentModel")]
[assembly: AssemblyDescription("A little component model and framework to write .NET components.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("MSpace")]
[assembly: AssemblyProduct("ComponentModel")]
[assembly: AssemblyCopyright("2005 (C) Néstor Salceda Alonso")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("0.2.*")]
