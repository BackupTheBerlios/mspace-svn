using System;
using ComponentModel;

namespace ComponentModel.ComponentTest.Components.MainComponent.Bo {
    [Component ("MainComponent", "ComponentModel.ComponentTest.Components.MainComponent.Exception.MainComponentExceptionManager")]
    public class MainComponentComponentModel : DefaultComponentModel {
    }
}
