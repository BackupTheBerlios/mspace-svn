using System;
using ComponentModel.ExceptionManager;

namespace ComponentModel.ComponentTest.Components.MainComponent.Exception {
    public class MainComponentExceptionManager : DefaultExceptionManager {
        public MainComponentExceptionManager () {
        }
        //public override void ProcessException (Exception exception) {
        //    base.ProcessException (exception); 
        //}
    }
}
